package io.fun;

public enum GameType {
    MINECRAFT, GOD_OF_WAR, CALL_OF_DUTY
}